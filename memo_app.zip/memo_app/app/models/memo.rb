class Memo < ApplicationRecord
end
