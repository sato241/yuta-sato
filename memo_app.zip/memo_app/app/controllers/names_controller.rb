class NamesController < ApplicationController
    def top
        #トップページが呼ばれた時のアクション
        @memos = Memo.all
    end
    
    def new
        #新規ページが呼ばれた時のアクション
    end
    
    def create
        #フォームからpostされた時のアクション
        Memo.create(titel:params["memos"]["titel"],body:params["memos"]["body"])
        redirect_to "/"
    end
    
    def destroy
        memo = Memo.find(params["id"])
        memo.destroy
        redirect_to "/"
    end
    
    def edit
        @memo = Memo.find(params["id"])
    end
    
    def update
        memo = Memo.find(params["id"])
        memo.titel = params["memos"]["titel"]
        memo.body = params["memos"]["body"]
        memo.save
        redirect_to "/"
    end
end
