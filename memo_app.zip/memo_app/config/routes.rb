Rails.application.routes.draw do
    root to:"names#top"
    get "/new",to:"names#new"
    post "/create",to:"names#create"
    delete "/memos/:id",to:"names#destroy"
    get "/memos/:id/edit",to:"names#edit"
    patch "/memos/:id",to:"names#update"
end
